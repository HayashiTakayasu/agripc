#coding:utf-8
require "./thermo_gruff2"
  include AgriController
  #p Dir.pwd
    #p Dir.glob('./thermo_data.csv.'+"*")
    #p day=`ruby yesterday_guess.rb`.chomp
    #input_csv_data="./thermo_data.csv"+"."+yesterday
  list=Dir.glob('./thermo_data/thermo_data.csv.'+"*")-Dir.glob('./thermo_data/thermo_data.csv.'+"*format*")
  #p list
  list.each do |input_csv_data|
    output_filename=input_csv_data+".jpg"
    if !(input_csv_data.include?(".jpg")) && File.readable?(input_csv_data) && !File.exist?(output_filename)
      p input_csv_data
      thermo_gruff2(output_filename,input_csv_data,range=[1.0,1.0/3,1.0/100],legend=["C","%(1/3)","CO2(1/100)"],view="640x540")
      
      #thermo_gruff2(output_filename,input_csv_data,range=[1.0,1.0/3,1.0/100,1.0,1.0/3,1.0/100],legend=["degree","humidty(1/3)","ppm(1/100)","degree","humidty(1/3)","ppm(1/100)"],"640x540")
    end
  end
